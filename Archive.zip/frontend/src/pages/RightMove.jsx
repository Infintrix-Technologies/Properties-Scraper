import React from 'react'
import Rightmovetable from '../components/Rightmovetable'

const RightMove = () => {
    return (
        <>
            <div className="mycontainer" style={{ padding: "25px" }}>
                <Rightmovetable />
            </div>
        </>
    )
}

export default RightMove