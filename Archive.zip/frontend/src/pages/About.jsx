import React from 'react'
import { Button, List, Popover, Space, Table, Tag, Typography } from 'antd';
const About = () => {
    
    return (
        <>
            <div className="mycontainer" style={{ padding: "25px" }}>

                <h1>About</h1>


            </div>
        </>
    )
}

export default About